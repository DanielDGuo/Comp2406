/*
Client-side javascript for 2406 assignment 1
COMP 2406 (c) Louis D. Nel 2023
*/

let song = {} //object representing the song being displayed
