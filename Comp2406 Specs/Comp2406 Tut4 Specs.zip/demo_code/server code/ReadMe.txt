Classroom example.

Here the static server maintains some hardcoded arrays that represent
lyrics from three songs:

Peaceful Easy Feeling
Sister Golden Hair
Brown Eyed Girl

You should be able to request those songs from the server.
The application is launched in the browser by visiting
http://localhost:3000/example1.html
